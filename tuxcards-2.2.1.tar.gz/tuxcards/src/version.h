/***************************************************************************
                          version.h  -  description
                             -------------------
    begin                : Don Sep 19 2002
    copyright            : (C) 2002 by alex
    email                : alex@rsh-318
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef VERSION_H
#define VERSION_H

 #define TUX_VERSION        "Version 2.2.1 - Qt4"
 #define TUX_SHORT_VERSION  "V2.2.1"


 // *** new features ***

 // displays the recently used files within a toolbar
 #define FEATURE_RECENTFILELIST_TOOLBAR


#endif
